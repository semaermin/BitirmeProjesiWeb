<?php

namespace Illuminate\Contracts\Broadcasting;

interface ShouldBeUnique
{
    //
}
