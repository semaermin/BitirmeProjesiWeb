<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportComputed\BaseComputed;

#[\Attribute]
class Computed extends BaseComputed
{
    //
}
