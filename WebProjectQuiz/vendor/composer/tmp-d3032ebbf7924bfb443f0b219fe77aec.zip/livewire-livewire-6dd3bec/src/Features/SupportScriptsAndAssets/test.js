
document.querySelector('[dusk="foo"]').textContent = 'evaluated'
